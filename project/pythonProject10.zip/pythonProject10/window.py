import pygame
import sys
import time


class Button:
    def __init__(self, y, text, images, images_1):
        self.x = 900 / 2 - (150 - 2)
        self.y = y
        self.width = 252
        self.height = 74
        self.text = text

        self.image = pygame.image.load(images).convert_alpha()
        self.image = pygame.transform.scale(self.image, (self.width, self.height))
        self.image_1 = self.image
        if images_1:
            self.image_1 = pygame.image.load(images_1)
            self.image_1 = pygame.transform.scale(self.image_1, (self.width, self.height))
        self.rect = self.image.get_rect(topleft=(self.x, self.y))
        self.sound = None
        self.flag = False

    def draw(self, screen):
        if self.flag:
            current_image = self.image_1
        else:
            current_image = self.image
        screen.blit(current_image.convert_alpha(screen), self.rect.topleft)

        font = pygame.font.Font(None, 36)
        text_surface = font.render(self.text, True, (255, 255, 255))
        text_rect = text_surface.get_rect(center=self.rect.center)
        screen.blit(text_surface.convert_alpha(screen), text_rect)

    def hovering_the_cursor(self, mouse_location):
        flag_1 = True
        if flag_1:
            self.flag = self.rect.collidepoint(mouse_location)

    def obrabotka_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and self.flag:
            pass

            pygame.event.post(pygame.event.Event(pygame.USEREVENT, button=self))


def main():
    game_scene = None

    def scene_switch(current_scene):
        global game_scene
        game_scene = current_scene

    def final_window(string):
        def draw(screen, string):
            screen.fill((0, 0, 0))
            font = pygame.font.Font(None, 100)
            text = font.render(string, True, (0, 255, 0))
            text_x = width // 2 - text.get_width() // 2
            text_y = height // 2 - text.get_height() // 2
            text_w = text.get_width()
            text_h = text.get_height()
            screen.blit(text, (text_x, text_y))
            pygame.draw.rect(screen, (0, 255, 0), (text_x - 10, text_y - 10,
                                                   text_w + 20, text_h + 20), 1)

        pygame.init()
        size = width, height = 1000, 750
        screen = pygame.display.set_mode(size)
        draw(screen, string)
        pygame.display.flip()
        pygame.display.set_caption('Финальное окно')
        running = True
        while running:
            time.sleep(5)
            running = False
        pygame.quit()
        sys.exit()


    def drakon_super(a, b, c, v, images, images2, images3):
        drakon = pygame.image.load(images)
        drakon2 = pygame.image.load(images2)
        drakon3 = pygame.image.load(images3)
        n = drakon.convert_alpha().get_rect(topleft=(a, b))
        n2 = drakon2.convert_alpha().get_rect(topleft=(a, b))
        n3 = drakon3.convert_alpha().get_rect(topleft=(a, b))
        n4 = c.get_rect(topleft=(v, 665))
        if n.colliderect(n4) or n2.colliderect(n4) or n3.colliderect(n4):
            return True
        else:
            return False

    def game_level_1():
        pygame.init()
        screen = pygame.display.set_mode((1500, 775))
        clock = pygame.time.Clock()
        pygame.display.set_caption('Уровень Базовый')
        icon = pygame.image.load('3262561.png')
        pygame.display.set_icon(icon)
        villains = pygame.image.load('s/2603009.png').convert_alpha()
        villains_1 = pygame.image.load('8335317.png').convert_alpha()
        villains_master = 1400
        villains_master_1 = 1200
        antagonists_count = 0
        flag_antoganists = True
        count_right = 0
        y_axis = 675
        final = 0
        jump_master = True
        x_axis = 0
        count_movement = 1400
        jump_count = 15
        musik = pygame.mixer.Sound('s/Фон для игры - Без названия.mp3')
        musik.play()
        count_right += 1
        antagonists_count += 1
        running = True
        running_2 = 1
        list_x_y = 0
        while running:
            if running_2 == 1:
                clock.tick(10)

                def heroes_villains():
                    screen.blit(pygame.image.load('fonts/future-city-art-cyberpunk-neon-3.webp').convert(),
                                (list_x_y, 0))
                    screen.blit(villains, (villains_master, 50))
                    screen.blit(villains_1, (villains_master_1, 50))

                heroes_villains()

                antagonists_1 = pygame.image.load('8335439.png').convert_alpha()
                if drakon_super(x_axis, y_axis, antagonists_1, count_movement, 's/drakon-/дракончики11.png',
                                's/drakon-/дракончики22.png', 's/drakon-/дракончики33.png'):
                    with open('result_level_1.txt', 'a', encoding='utf8') as file:
                        file.write(f' {final}/3 ')
                    running_2 = 0
                    scene_switch(final_window('Defeat!'))

                if count_right == 1:
                    screen.blit(pygame.image.load('s/drakon-/дракончики11.png').convert_alpha(), (x_axis, y_axis))
                elif count_right == 2:
                    screen.blit(pygame.image.load('s/drakon-/дракончики22.png').convert_alpha(), (x_axis, y_axis))
                elif count_right == 3:
                    screen.blit(pygame.image.load('s/drakon-/дракончики33.png').convert_alpha(), (x_axis, y_axis))
                elif count_right == 4:
                    screen.blit(pygame.image.load('s/drakon-/дракончики11.png').convert_alpha(), (x_axis, y_axis))
                    count_right = 0

                if flag_antoganists:
                    if antagonists_count == 1:
                        screen.blit(pygame.image.load('8335317.png').convert_alpha(), (count_movement, 665))
                    elif antagonists_count == 2:
                        screen.blit(pygame.image.load('8335439.png').convert_alpha(), (count_movement, 665))
                    elif antagonists_count == 3:
                        screen.blit(pygame.image.load('8335317.png').convert_alpha(), (count_movement, 665))
                    elif antagonists_count == 4:
                        screen.blit(pygame.image.load('8335439.png').convert_alpha(), (count_movement, 665))
                        antagonists_count = 0
                keys = pygame.key.get_pressed()
                if jump_master:
                    if keys[pygame.K_SPACE] or keys[pygame.K_UP]:
                        jump_master = False
                else:
                    if jump_count >= -15:
                        if jump_count > 0:
                            y_axis -= (jump_count ** 2) / (4 ** 0.5)
                        else:
                            y_axis += (jump_count ** 2) / (4 ** 0.5)
                        jump_count -= 1
                    else:
                        jump_master = True
                        jump_count = 15
                count_right += 1
                x_axis += 7
                count_movement -= 10
                if count_movement == 0:
                    count_movement = 1400
                antagonists_count += 1
                if x_axis >= 1500:
                    x_axis = 0
                    final += 1
                if final == 3:
                    with open('result_level_1.txt', 'a', encoding='utf8') as file_1:
                        string_result = ' 3/3 '
                        file_1.write(string_result)
                    running_2 = 0
                    scene_switch(final_window('Game over!'))
                villains_master -= 10
                villains_master_1 -= 10
                if villains_master_1 == 0:
                    villains_master_1 = 1400
                if villains_master == 0:
                    villains_master = 1400
                pygame.display.update()
                for event in pygame.event.get():
                    if keys[pygame.K_ESCAPE] or event.type == pygame.QUIT:
                        running = False

    def game_level_2():
        pygame.init()
        screen = pygame.display.set_mode((1500, 775))
        clock = pygame.time.Clock()
        pygame.display.set_caption('Уровень продвинутый')
        icon = pygame.image.load('7901412.png')
        pygame.display.set_icon(icon)
        villains = pygame.image.load('s/2603009.png').convert_alpha()
        villains_1 = pygame.image.load('8335439.png').convert_alpha()
        villains_master = 1400
        villains_master_1 = 1200
        antagonists_count = 0
        flag_antoganists = True
        count_right = 0
        y_axis = 675
        jump_master = True
        x_axis = 0
        y = 665
        count_movement = 1400
        final = 0
        jump_height = 12
        musik = pygame.mixer.Sound('s/Фон для игры - Без названия.mp3')
        musik.play()
        count_right += 1
        antagonists_count += 1
        running = True
        count_voln = 0
        list_x_y = 0
        running_2 = 1
        flag_bag = True
        while running:
            if running_2 == 1:
                clock.tick(10)

                def heroes_villains():
                    screen.blit(pygame.image.load('fonts/future-city-art-cyberpunk-neon-3.webp').convert(),
                                (list_x_y, 0))
                    screen.blit(villains, (villains_master, 50))
                    screen.blit(villains_1, (villains_master_1, 50))

                heroes_villains()
                if flag_bag:
                    kiberantagonists_1 = pygame.image.load('8335439.png').convert_alpha()
                    if drakon_super(x_axis, y_axis, kiberantagonists_1, count_movement, 's/drakon-/дракончики11.png',
                                    's/drakon-/дракончики22.png', 's/drakon-/дракончики33.png'):
                        with open('result_level_2.txt', 'a', encoding='utf8') as file:
                            file.write(f' {final}/8 ')
                        running_2 = 0
                        scene_switch(final_window('Defeat!'))

                if count_right == 1:
                    screen.blit(pygame.image.load('s/drakon-/дракончики11.png').convert_alpha(), (x_axis, y_axis))
                elif count_right == 2:
                    screen.blit(pygame.image.load('s/drakon-/дракончики22.png').convert_alpha(), (x_axis, y_axis))
                elif count_right == 3:
                    screen.blit(pygame.image.load('s/drakon-/дракончики33.png').convert_alpha(), (x_axis, y_axis))
                elif count_right == 4:
                    screen.blit(pygame.image.load('s/drakon-/дракончики11.png').convert_alpha(), (x_axis, y_axis))
                    count_right = 0

                if flag_antoganists:
                    if antagonists_count == 1:
                        screen.blit(pygame.image.load('8335317.png').convert_alpha(), (count_movement, y))
                    elif antagonists_count == 2:
                        screen.blit(pygame.image.load('8335439.png').convert_alpha(), (count_movement, y))
                    elif antagonists_count == 3:
                        screen.blit(pygame.image.load('8335317.png').convert_alpha(), (count_movement, y))
                    elif antagonists_count == 4:
                        screen.blit(pygame.image.load('8335439.png').convert_alpha(), (count_movement, y))
                        antagonists_count = 0

                keys = pygame.key.get_pressed()
                if keys[pygame.K_x]:
                    print('Вы взломали вирус!')
                    y = 200
                    flag_bag = False
                if keys[pygame.K_s]:
                    y = 665
                    flag_bag = True
                if jump_master:
                    if keys[pygame.K_UP] or keys[pygame.K_SPACE]:
                        jump_master = False
                else:
                    if jump_height >= -12:
                        if jump_height > 0:
                            y_axis -= (jump_height ** 2) / (4 ** 0.5)
                        else:
                            y_axis += (jump_height ** 2) / (4 ** 0.5)
                        jump_height -= 1
                    else:
                        jump_master = True
                        jump_height = 12

                count_right += 1
                x_axis += 15
                count_movement -= 15
                antagonists_count += 1
                if x_axis == 1500:
                    x_axis = 0
                    final += 1
                    count_voln += 1
                villains_master -= 10
                villains_master_1 -= 10
                if count_movement <= 0:
                    count_movement = 1400
                if villains_master_1 == 0:
                    villains_master_1 = 1400
                if villains_master == 0:
                    villains_master = 1400
                if final == 8:
                    with open('result_level_2.txt', 'a', encoding='utf8') as file_2:
                        string_result = ' 8/8 '
                        file_2.write(string_result)
                    running_2 = 0
                    scene_switch(final_window('Game over!'))
                pygame.display.update()
                for event in pygame.event.get():
                    if keys[pygame.K_ESCAPE] or event.type == pygame.QUIT:
                        running = False

    def result():
        print('Результаты по уровню 1')
        with open('result_level_1.txt', 'r') as files_1:
            files_1 = files_1.read()
            files_1 = files_1.split()
            if len(files_1) == 0:
                print('Результатов нет')
                print()
            else:
                list_result_1 = []
                for i, j in enumerate(files_1):
                    print(f'{i + 1}) {j} Волн')
                    list_result_1.append(int(j[0]))
                print(f'Наилучший результат: {max(list_result_1)} Волн')
                print()

        print('Результаты по уровню 2')
        with open('result_level_2.txt', 'r') as files_2:
            files_2 = files_2.read()
            files_2 = files_2.split()
            if len(files_2) == 0:
                print('Результатов нет')
                print()
            else:
                list_result_2 = []
                for ii, jj in enumerate(files_2):
                    print(f'{ii + 1}) {jj}')
                    list_result_2.append(int(jj[0]))
                print(f'Наилучший результат: {max(list_result_2)} Волн')
                print()

    def function_button():
        pygame.init()
        size = widht, height = 900, 700
        screen = pygame.display.set_mode(size)
        pygame.display.set_caption('Pygame')
        button1 = Button(100, 'Уровень 1', 'wigital.webp', 'wigital.webp')
        button2 = Button(200, 'Уровень 2', 'wigital.webp', 'wigital.webp')
        button3 = Button(300, 'Информация', 'wigital.webp', 'wigital.webp')
        button4 = Button(400, 'Результат', 'wigital.webp', 'wigital.webp')
        button5 = Button(500, 'Выйти', 'wigital.webp', 'wigital.webp')
        icon = pygame.image.load('s/2706092.png').convert_alpha()
        pygame.display.set_icon(icon)
        musik = pygame.mixer.Sound('b19fd19cd041148.mp3')
        musik.play()
        images = pygame.image.load('1602761575_006.jpg')

        def main_meny():
            running = True
            while running:
                screen.blit(images, (0, 0))

                font = pygame.font.Font(None, 50)
                text_surface = font.render('Стартовое окно', True, (0, 0, 255))
                text_rect = text_surface.get_rect(center=(430, 50))
                screen.blit(text_surface, text_rect)
                for event in pygame.event.get():
                    try:
                        if event.type == pygame.QUIT:
                            running = False
                            pygame.quit()
                            sys.exit()
                        if event.type == pygame.USEREVENT and event.button == button1:
                            print('Уровень 1')
                            scene_switch(game_level_1())
                            running = False
                        if event.type == pygame.USEREVENT and event.button == button2:
                            print('Уровень 2')
                            scene_switch(game_level_2())
                            running = False
                        if event.type == pygame.USEREVENT and event.button == button5:
                            pygame.quit()
                            sys.exit()
                        if event.type == pygame.USEREVENT and event.button == button4:
                            result()
                        if event.type == pygame.USEREVENT and event.button == button3:
                            try:
                                with open('information.txt', 'w', encoding='utf8') as file_1:
                                    information = (
                                        'Программа является эксперементом, несет строго развлекательный характер.\nУправление драконом осуществляется с помощью команд "пробел" и "стрелка вверх"')
                                    file_1.write(information)
                                    name = 'information.txt'
                                    print(f'Файл {name} скачался')
                            except BaseException as e:
                                n = 'Возникла ошибка:'
                                print(f'{n} {e}')

                        button1.obrabotka_event(event)
                        button2.obrabotka_event(event)
                        button3.obrabotka_event(event)
                        button4.obrabotka_event(event)
                        button5.obrabotka_event(event)
                        button1.hovering_the_cursor(pygame.mouse.get_pos())
                        button1.draw(screen)
                        button2.hovering_the_cursor(pygame.mouse.get_pos())
                        button2.draw(screen)
                        button3.hovering_the_cursor(pygame.mouse.get_pos())
                        button3.draw(screen)
                        button4.hovering_the_cursor(pygame.mouse.get_pos())
                        button4.draw(screen)
                        button5.hovering_the_cursor(pygame.mouse.get_pos())
                        button5.draw(screen)
                        pygame.display.flip()
                    except pygame.error:
                        print('')

        main_meny()

    if __name__ == '__main__':
        scene_switch(function_button())
        while game_scene is not None:
            game_scene()


if __name__ == '__main__':
    main()

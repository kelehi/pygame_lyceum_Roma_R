def resulf():
    with open('ww', 'r'):
        pass
import pygame
import sys
from files import Button

class Window():
    def __init__(self):
        self.c = []

    def function(self):
        pygame.init()
        size = widht, height = 900, 700
        screen = pygame.display.set_mode(size)
        pygame.display.set_caption('Button')
        green_button1 = Button(widht / 2 - (150 - 2), 100, 252, 74, 'Уровень 1', 'wigital.webp', 'wigital.webp')
        green_button2 = Button(widht / 2 - (150 - 2), 200, 252, 74, 'Уровень 2', 'wigital.webp', 'wigital.webp')
        green_button3 = Button(widht / 2 - (150 - 2), 300, 252, 74, 'Выйти', 'wigital.webp', 'wigital.webp')
        musik = pygame.mixer.Sound('b19fd19cd041148.mp3')
        musik.play()
        images = pygame.image.load('1602761575_006.jpg')

        def main_meny():
            running = True
            while running:
                screen.blit(images, (0, 0))

                font = pygame.font.Font(None, 50)
                text_surface = font.render('Стартовое окно', True, (0, 0, 255))
                text_rect = text_surface.get_rect(center=(430, 50))
                screen.blit(text_surface, text_rect)
                for event in pygame.event.get():
                    try:
                        if event.type == pygame.QUIT:
                            running = False
                            pygame.quit()
                            sys.exit()
                        if event.type == pygame.USEREVENT and event.button == green_button1:
                            print('Уровень 1')
                            self.c.append('1')
                        if event.type == pygame.USEREVENT and event.button == green_button2:
                            print('Уровень 2')
                            self.c.append('2')
                        if event.type == pygame.USEREVENT and event.button == green_button3:
                            pygame.quit()
                            sys.exit()
                        green_button1.handle_event(event)
                        green_button2.handle_event(event)
                        green_button3.handle_event(event)
                        green_button1.check_hover(pygame.mouse.get_pos())
                        green_button1.draw(screen)
                        green_button2.check_hover(pygame.mouse.get_pos())
                        green_button2.draw(screen)
                        green_button3.check_hover(pygame.mouse.get_pos())
                        green_button3.draw(screen)
                        pygame.display.flip()
                    except pygame.error:
                        print('error')

        main_meny()

    def window_1(self):
        self.c.clear()

    def print_resulf(self):
        print(self.c if len(self.c) != 0 else 'error')

if __name__ == '__main__':
    v = Window()
    v.function()
from files import Button1, Button2, Button3, Button4, Button5
import pygame
import sys
from windowfile_1 import zmeika

cur_sc = None
reslt = 0


def result(reslt):
    try:
        with open('result.txt', 'a') as file:
            file.write(reslt.__str__())
    except BaseException as e:
        print(e)



def switch_scene(current_scene):
    global cur_sc
    cur_sc = current_scene


def game():
    list_random = []
    clock = pygame.time.Clock()
    pygame.init()
    screen = pygame.display.set_mode((1500, 800))
    pygame.display.set_caption('Дракон')
    icon = pygame.image.load('s/2706092.png')
    pygame.display.set_icon(icon)
    ghost = pygame.image.load('s/2603009.png')
    player = pygame.image.load('s/leftgame/x1670754038.png.pagespeed.ic.Z3RY1P6uWG.png')
    rn1 = pygame.image.load('s/drakon-/дракончики11.png').convert_alpha()
    rn2 = pygame.image.load('s/drakon-/дракончики22.png').convert_alpha()
    rn3 = pygame.image.load('s/drakon-/дракончики33.png').convert_alpha()
    rn4 = pygame.image.load('s/drakon-/дракончики11.png').convert_alpha()
    count_right = 0
    player_x = 150
    player_y = 750
    ghost_timer = pygame.USEREVENT + 1
    pygame.time.set_timer(ghost_timer, 8000)
    is_jump = False
    count_1 = 0
    jump_count = 15
    bg_s = pygame.mixer.Sound('s/Фон для игры - Без названия.mp3')
    bg_s.play()
    count_right += 1
    running = True
    list_x_y = 0
    while running:
        clock.tick(10)
        screen.blit(pygame.image.load('fonts/future-city-art-cyberpunk-neon-3.webp').convert(), (list_x_y, 0))
        if count_right == 1:
            screen.blit(rn1, (count_1, 675))
        elif count_right == 2:
            screen.blit(rn2, (count_1, 675))
        elif count_right == 3:
            screen.blit(rn3, (count_1, 675))
        elif count_right == 4:
            screen.blit(rn4, (count_1, 675))
            count_right = 0
        keys = pygame.key.get_pressed()
        count_right += 1
        count_1 += 5
        result(count_1)
        if count_1 == 1500:
            count_1 = 0
        pygame.display.update()
        for event in pygame.event.get():
            if keys[pygame.K_ESCAPE] or event.type == pygame.QUIT:
                running = False


def function():
    pygame.init()
    size = widht, height = 900, 700
    screen = pygame.display.set_mode(size)
    pygame.display.set_caption('Pygame')
    green_button1 = Button1(widht / 2 - (150 - 2), 100, 'Уровень 1', 'wigital.webp', 'wigital.webp')
    green_button2 = Button2(widht / 2 - (150 - 2), 200, 'Уровень 2', 'wigital.webp', 'wigital.webp')
    green_button3 = Button3(widht / 2 - (150 - 2), 300, 'Информация', 'wigital.webp', 'wigital.webp')
    green_button4 = Button4(widht / 2 - (150 - 2), 400, 'Результат', 'wigital.webp', 'wigital.webp')
    green_button5 = Button5(widht / 2 - (150 - 2), 500, 'Выйти', 'wigital.webp', 'wigital.webp')
    icon = pygame.image.load('s/2706092.png').convert_alpha()
    pygame.display.set_icon(icon)
    musik = pygame.mixer.Sound('b19fd19cd041148.mp3')
    musik.play()
    images = pygame.image.load('1602761575_006.jpg')


    def main_meny():
        running = True
        while running:
            screen.blit(images, (0, 0))

            font = pygame.font.Font(None, 50)
            text_surface = font.render('Стартовое окно', True, (0, 0, 255))
            text_rect = text_surface.get_rect(center=(430, 50))
            screen.blit(text_surface, text_rect)
            for event in pygame.event.get():
                try:
                    if event.type == pygame.QUIT:
                        running = False
                        pygame.quit()
                        sys.exit()
                    if event.type == pygame.USEREVENT and event.button == green_button1:
                        print('Уровень 1')
                        switch_scene(game())
                        running = False
                    if event.type == pygame.USEREVENT and event.button == green_button2:
                        switch_scene(zmeika())
                        running = False
                    if event.type == pygame.USEREVENT and event.button == green_button5:
                        pygame.quit()
                        sys.exit()
                    if event.type == pygame.USEREVENT and event.button == green_button4:
                        print('1')
                    if event.type == pygame.USEREVENT and event.button == green_button3:
                        try:
                            with open('information.txt', 'w', encoding='utf8') as file_1:
                                information = 'Программа является эксперементом, несет строго развлекательный характер'
                                file_1.write(information)
                                print('Файл скачался')
                        except BaseException as e:
                            n = 'Возникла ошибка:'
                            print(f'{n} {e}')

                    green_button1.handle_event(event)
                    green_button2.handle_event(event)
                    green_button3.handle_event(event)
                    green_button4.handle_event(event)
                    green_button5.handle_event(event)
                    green_button1.check_hover(pygame.mouse.get_pos())
                    green_button1.draw(screen)
                    green_button2.check_hover(pygame.mouse.get_pos())
                    green_button2.draw(screen)
                    green_button3.check_hover(pygame.mouse.get_pos())
                    green_button3.draw(screen)
                    green_button4.check_hover(pygame.mouse.get_pos())
                    green_button4.draw(screen)
                    green_button5.check_hover(pygame.mouse.get_pos())
                    green_button5.draw(screen)
                    pygame.display.flip()
                except pygame.error:
                    print('error')

    main_meny()


if __name__ == '__main__':
    switch_scene(function())
    while cur_sc is not None:
        cur_sc()

import pygame
import copy

def zmeika():
    pass
